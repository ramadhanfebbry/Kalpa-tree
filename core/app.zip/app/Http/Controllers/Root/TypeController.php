<?php

namespace App\Http\Controllers\Root;

use App\Http\Requests;
use App\Http\Controllers\Controller;

use App\Type;
use App\TypeArea;
use App\Area;
use Illuminate\Http\Request;
use Session;
use Datatables;
use DB;
use Auth;
use File;

class TypeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('root');
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\View\View
     */
    public function index()
    {
        return view('root.type.index');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\View\View
     */
    public function create()
    {
        return view('root.type.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param \Illuminate\Http\Request $request
     *
     * @return \Illuminate\Http\RedirectResponse|\Illuminate\Routing\Redirector
     */
    public function store(Request $request)
    {
        $this->validate($request, [
          'name' => 'required|max:255|unique:categories',
    		]);
      
        $file = $request->file('file');
        $destinationPath = 'files/types';
        $ext = File::extension($file->getClientOriginalName());
        $filename = strtolower(str_replace(" ", "-", $request->name)."-".str_random(3)).".".$ext;
        $request["icon"] = $filename;
        $file->move($destinationPath, $filename);
      
        $requestData = $request->all();

        $user = Type::create($requestData);

        Session::flash('flash_message', 'Type added!');

        return redirect('root/type');
      
      
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     *
     * @return \Illuminate\View\View
     */
    public function show($id)
    {
        $user = Type::findOrFail($id);

        return view('root.type.show', compact('user'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     *
     * @return \Illuminate\View\View
     */
    public function edit($id)
    {
        $type = Type::findOrFail($id);
        return view('root.type.edit', compact('type'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  int  $id
     * @param \Illuminate\Http\Request $request
     *
     * @return \Illuminate\Http\RedirectResponse|\Illuminate\Routing\Redirector
     */
    public function update($id, Request $request)
    {
        $this->validate($request, [
          'name' => 'required|max:255',
		]);
        
        if($request->file('file')){
          $file = $request -> file('file');
          $destinationPath = 'files/types';
          $ext = File::extension($file->getClientOriginalName());
          $filename = strtolower(str_replace(" ", "-", $request->name)."-".str_random(3)).".".$ext;
          $file->move($destinationPath, $filename);
          File::delete($destinationPath."/".$request->icon);
          $request["icon"] = $filename;
        }else{
          $request["icon"] = $request->icon;
        }
        $requestData = $request->all();

        $user = Type::findOrFail($id);
        $user->update($requestData);

        Session::flash('flash_message', 'Type updated!');

        return redirect('root/type');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     *
     * @return \Illuminate\Http\RedirectResponse|\Illuminate\Routing\Redirector
     */
    public function destroy($id)
    {
        $destinationPath = 'files/categories';
        $cat = Type::findOrFail($id);
        File::delete($destinationPath."/".$cat->icon);
        Type::destroy($id);

        Session::flash('flash_message', 'Type deleted!');

        return redirect('root/type');
    }

    public function anyData(Request $request)
    {
        DB::statement(DB::raw('set @rownum=0'));
        $user = Type::select([
            DB::raw('@rownum  := @rownum  + 1 AS rownum'), 'id', 'name',
            'icon', 'description']);

         $datatables = app('datatables')->of($user)
            ->addColumn('action', function ($user) {
                return '<a href="type/'.$user->id.'/edit" class="btn btn-xs btn-primary rounded" data-toggle="tooltip" title="" data-original-title="'. trans('systems.edit') .'"><i class="fa fa-pencil"></i></a> <a onclick="deleteData('.$user->id.')" class="btn btn-xs btn-danger rounded" data-toggle="tooltip" title="" data-original-title="'. trans('systems.delete') .'"><i class="fa fa-trash"></i></a>';
            });

        if ($keyword = $request->get('search')['value']) {
            $datatables->filterColumn('rownum', 'whereRaw', '@rownum  + 1 like ?', ["%{$keyword}%"]);
        }

        if ($range = $datatables->request->get('range')) {
            $rang = explode(":", $range);
            if($rang[0] != "Invalid date" && $rang[1] != "Invalid date" && $rang[0] != $rang[1]){
                $datatables->whereBetween('created_at', ["$rang[0] 00:00:00", "$rang[1] 23:59:59"]);
            }else if($rang[0] != "Invalid date" && $rang[1] != "Invalid date" && $rang[0] == $rang[1]) {
                $datatables->whereBetween('created_at', ["$rang[0] 00:00:00", "$rang[1] 23:59:59"]);
            }
        }



        return $datatables->make(true);
    }
}
