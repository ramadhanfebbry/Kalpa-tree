<?php

namespace App\Http\Controllers\Root;

use App\Http\Requests;
use App\Http\Controllers\Controller;

use App\Category;
use App\CategoryArea;
use App\Area;
use Illuminate\Http\Request;
use Session;
use Datatables;
use DB;
use Auth;
use File;

class CategoryController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('root');
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\View\View
     */
    public function index()
    {
        return view('root.category.index');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\View\View
     */
    public function create()
    {
        return view('root.category.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param \Illuminate\Http\Request $request
     *
     * @return \Illuminate\Http\RedirectResponse|\Illuminate\Routing\Redirector
     */
    public function store(Request $request)
    {
        $this->validate($request, [
          'name' => 'required|max:255|unique:categories',
    		]);
      
        $file = $request->file('file');
        $destinationPath = 'files/categories';
        $ext = File::extension($file->getClientOriginalName());
        $filename = strtolower(str_replace(" ", "-", $request->name)."-".str_random(3)).".".$ext;
        $request["image"] = $filename;
        $file->move($destinationPath, $filename);
      
        $requestData = $request->all();

        $user = Category::create($requestData);

        Session::flash('flash_message', 'Category added!');

        return redirect('root/category');
      
      
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     *
     * @return \Illuminate\View\View
     */
    public function show($id)
    {
        $user = Category::findOrFail($id);

        return view('root.category.show', compact('user'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     *
     * @return \Illuminate\View\View
     */
    public function edit($id)
    {
        $category = Category::findOrFail($id);
        return view('root.category.edit', compact('category'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  int  $id
     * @param \Illuminate\Http\Request $request
     *
     * @return \Illuminate\Http\RedirectResponse|\Illuminate\Routing\Redirector
     */
    public function update($id, Request $request)
    {
        $this->validate($request, [
          'name' => 'required|max:255',
		]);
        
        if($request->file('file')){
          $file = $request -> file('file');
          $destinationPath = 'files/categories';
          $ext = File::extension($file->getClientOriginalName());
          $filename = strtolower(str_replace(" ", "-", $request->name)."-".str_random(3)).".".$ext;
          $file->move($destinationPath, $filename);
          File::delete($destinationPath."/".$request->image);
          $request["image"] = $filename;
        }else{
          $request["image"] = $request->image;
        }
        $requestData = $request->all();

        $user = Category::findOrFail($id);
        $user->update($requestData);

        Session::flash('flash_message', 'Category updated!');

        return redirect('root/category');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     *
     * @return \Illuminate\Http\RedirectResponse|\Illuminate\Routing\Redirector
     */
    public function destroy($id)
    {
        $destinationPath = 'files/categories';
        $cat = Category::findOrFail($id);
        File::delete($destinationPath."/".$cat->image);
        Category::destroy($id);

        Session::flash('flash_message', 'Category deleted!');

        return redirect('root/category');
    }

    public function anyData(Request $request)
    {
        DB::statement(DB::raw('set @rownum=0'));
        $user = Category::select([
            DB::raw('@rownum  := @rownum  + 1 AS rownum'), 'id', 'name',
            'image', 'description']);

         $datatables = app('datatables')->of($user)
            ->addColumn('action', function ($user) {
                return '<a href="category/'.$user->id.'/edit" class="btn btn-xs btn-primary rounded" data-toggle="tooltip" title="" data-original-title="'. trans('systems.edit') .'"><i class="fa fa-pencil"></i></a> <a onclick="deleteData('.$user->id.')" class="btn btn-xs btn-danger rounded" data-toggle="tooltip" title="" data-original-title="'. trans('systems.delete') .'"><i class="fa fa-trash"></i></a>';
            });

        if ($keyword = $request->get('search')['value']) {
            $datatables->filterColumn('rownum', 'whereRaw', '@rownum  + 1 like ?', ["%{$keyword}%"]);
        }

        if ($range = $datatables->request->get('range')) {
            $rang = explode(":", $range);
            if($rang[0] != "Invalid date" && $rang[1] != "Invalid date" && $rang[0] != $rang[1]){
                $datatables->whereBetween('created_at', ["$rang[0] 00:00:00", "$rang[1] 23:59:59"]);
            }else if($rang[0] != "Invalid date" && $rang[1] != "Invalid date" && $rang[0] == $rang[1]) {
                $datatables->whereBetween('created_at', ["$rang[0] 00:00:00", "$rang[1] 23:59:59"]);
            }
        }



        return $datatables->make(true);
    }
}
