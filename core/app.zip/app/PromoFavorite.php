<?php

namespace App;

class PromoFavorite extends BaseModel
{
    /**
     * The database table used by the model.
     *
     * @var string
     */
    protected $table = 'promo_favorites';

    /**
    * The database primary key value.
    *
    * @var string
    */
    protected $primaryKey = 'id';

    /**
     * Attributes that should be mass-assignable.
     *
     * @var array
     */
    protected $fillable = ['id_promo', 'id_user', 'status'];

	/**
	 * @return \App\Promo
	 */
	public function promo()
	{
		return $this->hasOne('\App\Promo', 'id', 'id_promo');
	}
	
	/**
	 * @return \App\User
	 */
	public function user()
	{
		return $this->hasOne('\App\User', 'id', 'id_user');
	}
}
