<?php

namespace App;

class PromoHasCategory extends BaseModel
{
    /**
     * The database table used by the model.
     *
     * @var string
     */
    protected $table = 'promo_has_categories';

    /**
    * The database primary key value.
    *
    * @var string
    */
    protected $primaryKey = 'id';

    /**
     * Attributes that should be mass-assignable.
     *
     * @var array
     */
    protected $fillable = ['id_promo', 'id_promo_category', 'status'];
	
	/**
	 * @return type
	 */
	public function promoCategory()
	{
		return $this->hasOne('\App\PromoCategory', 'id', 'id_promo_category');
	}
}
