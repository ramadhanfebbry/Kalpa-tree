<?php

namespace App;

class PromoReview extends BaseModel
{
    
}
