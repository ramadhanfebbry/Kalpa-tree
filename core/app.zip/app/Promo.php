<?php

namespace App;

use Illuminate\Database\Eloquent\SoftDeletes;

class Promo extends BaseModel
{
	use SoftDeletes;
	
	const DESTINATION_PATH = 'files/promos';
	
    /**
     * The database table used by the model.
     *
     * @var string
     */
    protected $table = 'promos';

    /**
    * The database primary key value.
    *
    * @var string
    */
    protected $primaryKey = 'id';

    /**
     * Attributes that should be mass-assignable.
     *
     * @var array
     */
    protected $fillable = [
		'id_merchant',
		'id_branch',
		'id_bank',
		'id_promo_type',
		'title', 
		'latitude', 
		'longitude', 
		'image', 
		'term_condition',
		'discount',
		'start_date', 
		'end_date', 
		'status',
	];
	
	/**
     * The attributes that should be mutated to dates.
     *
     * @var array
     */
    protected $dates = ['deleted_at'];
	
	/**
	 * @return type
	 */
	public function merchant()
	{
		return $this->hasOne('App\Merchant', 'id', 'id_merchant');
	}
	
	/**
	 * @return type
	 */
	public function bank()
	{
		return $this->hasOne('\App\Bank', 'id', 'id_bank');
	}
	
	/**
	 * @return url
	 */
	public function getImageUrl()
	{
		if ($this->image == null) {
			return null;
		}
		
		return url(self::DESTINATION_PATH . '/' . $this->image);
	}
}
