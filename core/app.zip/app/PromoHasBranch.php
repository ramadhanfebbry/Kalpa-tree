<?php

namespace App;

class PromoHasBranch extends BaseModel
{
    /**
     * The database table used by the model.
     *
     * @var string
     */
    protected $table = 'promo_has_branchs';

    /**
    * The database primary key value.
    *
    * @var string
    */
    protected $primaryKey = 'id';

    /**
     * Attributes that should be mass-assignable.
     *
     * @var array
     */
    protected $fillable = ['id_promo', 'id_branch', 'status'];
	
	/**
	 * @return type
	 */
	public function branch()
	{
		return $this->hasOne('\App\Branch', 'id', 'id_branch');
	}
}