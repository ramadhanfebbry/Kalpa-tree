<?php

namespace App;

class MerchantImage extends BaseModel
{
	const DESTINATION_PATH = 'files/merchant-images';
	
    /**
     * The database table used by the model.
     *
     * @var string
     */
    protected $table = 'merchant_images';

    /**
    * The database primary key value.
    *
    * @var string
    */
    protected $primaryKey = 'id';

    /**
     * Attributes that should be mass-assignable.
     *
     * @var array
     */
    protected $fillable = ['id_merchant', 'image', 'status'];

	/**
	 * @return \App\merchant
	 */
	public function merchant()
	{
		return $this->hasOne('\App\Merchant', 'id', 'id_merchant');
	}
	
	/**
	 * @return url
	 */
	public function getImageUrl()
	{
		return url(self::DESTINATION_PATH . '/' . $this->image);
	}
}
