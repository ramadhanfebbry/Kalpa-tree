<?php

namespace App;

class Merchant extends BaseModel
{
    /**
     * The database table used by the model.
     *
     * @var string
     */
    protected $table = 'merchants';

    /**
    * The database primary key value.
    *
    * @var string
    */
    protected $primaryKey = 'id';

    /**
     * Attributes that should be mass-assignable.
     *
     * @var array
     */
    protected $fillable = ['id_category', 'name', 'address', 'phone', 'website', 'latitude', 'longitude', 'status'];

	/**
	 * @return \App\Branch
	 */
	public function branchs()
	{
		return $this->hasMany('\App\Branch', 'id_merchant', 'id');
	}
	
	/**
	 * @return \App\Type
	 */
	public function category()
	{
		return $this->hasOne('\App\Category', 'id', 'id_category');
	}
	
	/**
	 * @return \App\MerchantImage
	 */
	public function merchantImages()
	{
		return $this->hasMany('\App\MerchantImage', 'id_merchant', 'id');
	}
	
	/**
	 * @return \App\MerchantOpeningHour
	 */
	public function merchantOpeningHours()
	{
		return $this->hasMany('\App\MerchantOpeningHour', 'id_merchant', 'id')->orderBy('number_of_day');
	}
	
	/**
	 * @return \App\MerchantReview
	 */
	public function merchantReviews()
	{
		return $this->hasMany('\App\MerchantReview', 'id_merchant', 'id');
	}
	
	/**
	 * @return \App\MerchantReview
	 */
	public function reviewExceptional()
	{
		return number_format($this->hasMany('\App\MerchantReview', 'id_merchant', 'id')->avg('exceptional'), 1);
	}
	
	/**
	 * @return \App\MerchantReview
	 */
	public function reviewPeopleRated()
	{
		return $this->hasMany('\App\MerchantReview', 'id_merchant', 'id')->count();
	}
}
