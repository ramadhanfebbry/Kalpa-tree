<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

abstract class BaseModel extends Model
{
	const STATUS_ACTIVE = 1;
	const STATUS_INACTIVE = 0;
	
    /**
	 * @return array
	 */
    public static function statusLabels()
	{
		return [
			self::STATUS_ACTIVE => 'Active',
			self::STATUS_INACTIVE => 'Inactive',
		];
	}
	
	/**
	 * @return string
	 */
	public function getStatusText()
	{
		$list = self::statusLabels();
		
		return $list[$this->status] ? $list[$this->status] : $this->status;
	}
	
	/**
	 * @return boolean
	 */
	public function getIsStatusActive()
	{
		return $this->status == self::STATUS_ACTIVE;
	}
	
	/**
	 * @param type $query
	 * @return query
	 */
	public function scopeActived($query)
	{
		return $query->where('status', self::STATUS_ACTIVE);
	}
}
