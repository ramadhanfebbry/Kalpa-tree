<?php

namespace App;

use Illuminate\Database\Eloquent\SoftDeletes;

class MerchantOpeningHour extends BaseModel
{
	use SoftDeletes;
	
    /**
     * The database table used by the model.
     *
     * @var string
     */
    protected $table = 'merchant_opening_hours';

    /**
    * The database primary key value.
    *
    * @var string
    */
    protected $primaryKey = 'id';

    /**
     * Attributes that should be mass-assignable.
     *
     * @var array
     */
    protected $fillable = ['id_merchant', 'number_of_day', 'opening', 'closing', 'status'];
	
	/**
     * The attributes that should be mutated to dates.
     *
     * @var array
     */
    protected $dates = ['deleted_at'];

	/**
	 * @return Merchant
	 */
	public function merchant()
	{
		return $this->hasOne('\App\Merchant', 'id', 'id_merchant');
	}
}
