<?php

namespace App;

use Illuminate\Database\Eloquent\SoftDeletes;

class PromoCategory extends BaseModel
{
    use SoftDeletes;
	
    /**
     * The database table used by the model.
     *
     * @var string
     */
    protected $table = 'promo_categories';

    /**
    * The database primary key value.
    *
    * @var string
    */
    protected $primaryKey = 'id';

    /**
     * Attributes that should be mass-assignable.
     *
     * @var array
     */
    protected $fillable = ['name', 'description', 'status'];
	
	/**
     * The attributes that should be mutated to dates.
     *
     * @var array
     */
    protected $dates = ['deleted_at'];

	/**
	 * @return type
	 */
	public function promoHasCategories()
	{
		return $this->hasMany('\App\PromoHasCategory', 'id_promo_category', 'id');
	}
}
