<?php

namespace App;

use Illuminate\Database\Eloquent\SoftDeletes;

class Branch extends BaseModel
{
	use SoftDeletes;
	
    /**
     * The database table used by the model.
     *
     * @var string
     */
    protected $table = 'branchs';

    /**
    * The database primary key value.
    *
    * @var string
    */
    protected $primaryKey = 'id';

    /**
     * Attributes that should be mass-assignable.
     *
     * @var array
     */
    protected $fillable = ['id_merchant', 'name', 'address', 'phone', 'latitude', 'longitude' ];

	/**
     * The attributes that should be mutated to dates.
     *
     * @var array
     */
    protected $dates = ['deleted_at'];
	
	public function merchant()
  	{
  		return $this->hasOne('App\Merchant', 'id', 'id_merchant');
  	}
}