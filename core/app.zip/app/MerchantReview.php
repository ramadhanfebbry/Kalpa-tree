<?php

namespace App;

use Illuminate\Database\Eloquent\SoftDeletes;

class MerchantReview extends BaseModel
{
	use SoftDeletes;
	
    /**
     * The database table used by the model.
     *
     * @var string
     */
    protected $table = 'merchant_reviews';

    /**
    * The database primary key value.
    *
    * @var string
    */
    protected $primaryKey = 'id';

    /**
     * Attributes that should be mass-assignable.
     *
     * @var array
     */
    protected $fillable = ['id_merchant', 'id_user', 'cleaniess', 'service', 'food_dining', 'facilities', 'room_comfort', 'value_for_money', 'exceptional', 'status'];
	
	/**
     * The attributes that should be mutated to dates.
     *
     * @var array
     */
    protected $dates = ['deleted_at'];

	/**
	 * @return Promo
	 */
	public function merchant()
	{
		return $this->hasOne('\App\Merchant', 'id', 'id_merchant');
	}
	
	/**
	 * @return User
	 */
	public function user()
	{
		return $this->hasOne('\App\User', 'id', 'id_user');
	}
}
