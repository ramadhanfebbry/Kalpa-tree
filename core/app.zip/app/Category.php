<?php

namespace App;

use Illuminate\Database\Eloquent\SoftDeletes;

class Category extends BaseModel
{
	use SoftDeletes;
	
	const DESTINATION_PATH = 'files/categories';
	
    /**
     * The database table used by the model.
     *
     * @var string
     */
    protected $table = 'categories';

    /**
    * The database primary key value.
    *
    * @var string
    */
    protected $primaryKey = 'id';

    /**
     * Attributes that should be mass-assignable.
     *
     * @var array
     */
    protected $fillable = ['name', 'description', 'image', 'icon', 'status' ];
	
	/**
     * The attributes that should be mutated to dates.
     *
     * @var array
     */
    protected $dates = ['deleted_at'];

	/**
	 * @return type
	 */
    public function merchants()
  	{
  		return $this->hasMany('App\Merchant', 'id_category', 'id');
  	}
	
	/**
	 * @return url
	 */
	public function getImageUrl()
	{
		if ($this->image == null) {
			return null;
		}
		
		return url(self::DESTINATION_PATH . '/' . $this->image);
	}
	
	/**
	 * @return url
	 */
	public function getIconUrl()
	{
		if ($this->icon == null) {
			return null;
		}
		
		return url(self::DESTINATION_PATH . '/' . $this->icon);
	}
}
